#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist

class Mycontroller(Node):

    def __init__(self):
        super().__init__("controller")
        self.cmd_vel_publisher_ = self.create_publisher(
            Twist, "/turtle1/cmd_vel", 10
        )
        self.pose_subscriber_ = self.create_subscription(
            Pose, "/turtle1/pose"
        )
        self.get_logger().info("Turtle controller has been started")

    def pose_callback(self,pose:Pose):
        cmd = Twist()
        cmd.linear.x = 5.0
        cmd.angular.z = 0.0
        self.cmd_vel_publisher_.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = Mycontroller()
    rclpy.spin(node)
    rclpy.shutdown()
clear
